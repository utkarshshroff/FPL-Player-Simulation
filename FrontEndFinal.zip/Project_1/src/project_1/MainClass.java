/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_1;

import java.sql.Connection;
import java.sql.DriverManager;

public class MainClass {

    private static Connection c;
    private static int view = 1;
    private static int id = -1;
    private boolean running = true;
    private static WatchList_View w;
    private static Stat_view s;
    private static Admin_View a;
    private static Log_In l;

    public static void update() {
        w = new WatchList_View(id);
    }

    public static void setView(int x) {
        view = x;
    }

    public static void updateS(String st, String w) {
        s = new Stat_view(id, st, w);
    }

    public static void updateL(int x) {
        l = new Log_In(x);
    }

    public static void updateA() {
        a = new Admin_View();
    }

    public static void setId(int g) {
        id = g;
    }

    public int getViewId() {
        return this.view;
    }

    public boolean getRunning() {
        return this.running;
    }

    public int getUserId() {
        return this.id;
    }

    public static Connection getCon() {
        return c;
    }

    public static void main(String[] args) {

        try {
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/FPLHandbook", "USERNAME", "PASSWORD");

        } catch (Exception e) {
            System.out.println("failed login to database");
            e.getMessage();
        }

        l = new Log_In();
        w = new WatchList_View();
        s = new Stat_view();
        a = new Admin_View();
        ViewManager manage = new ViewManager(1, -1);

        while (manage.getRun()) {
            s.setId(l.getId());
            w.setId(l.getId());

            //login view
            if (manage.getView() == 1) {
                l.setVisible(true);
                manage.changeView(l.getView(), l.getId());
            } //watchlist view
            else if (manage.getView() == 2) {
                l.setVisible(false);
                s.setVisible(false);
                w.setVisible(true);
                manage.changeView(w.getView(), l.getId());
                w.resetView();
            } //stats view
            else if (manage.getView() == 3) {
                l.setVisible(false);
                w.setVisible(false);
                s.setVisible(true);
                manage.changeView(s.getView(), l.getId());
                s.resetView();
            } //admin view
            else if (manage.getView() == 4) {
                l.setVisible(false);
                s.setVisible(false);
                w.setVisible(false);
                a.setVisible(true);
                manage.changeView(l.getView(), l.getId());
            } //exit
            else if (manage.getView() == 5) {
                l.setVisible(false);
                w.setVisible(false);
                s.setVisible(false);
                System.exit(0);
            }

        }

    }

}
