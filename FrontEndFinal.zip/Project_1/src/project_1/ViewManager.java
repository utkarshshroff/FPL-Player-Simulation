/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_1;

/**
 *
 * @author jakechoward
 */
public class ViewManager {

    private int view;
    private int id;
    private boolean running;

    public ViewManager(int view, int id) {
        this.view = view;
        this.id = id;
        this.running = true;
    }

    public void changeView(int view, int id) {
        this.view = view;
        this.id = id;
    }

    public int getView() {
        return this.view;
    }

    public int getId() {
        return this.id;
    }

    public boolean getRun() {
        return this.running;
    }
}
